package com.cleartrip.base;

import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.io.File;

public class BasePage {

	public WebDriver driver;
	public ExtentTest test;
	
	
	public BasePage(WebDriver driver, ExtentTest test){
		
		this.driver=driver;
		this.test=test;
	}
	
	public void selFromToDate(){
		
		List<WebElement> datePicker = driver.findElements(By.xpath("//i[contains(@class, 'datePicker')]"));
		System.out.println("Date Picker size: "+datePicker.size());
		
		datePicker.get(0).click();
		
		WebElement tbody= driver.findElement(By.tagName("tbody"));
		List<WebElement> dateRows = driver.findElements(By.tagName("tr"));
		
		System.out.println("Total rows are: "+dateRows.size());
		
		List<WebElement> dates = dateRows.get(4).findElements(By.tagName("td"));
		System.out.println("Total dates: "+dates.size());
		
		dates.get(0).click();
		
		datePicker.get(1).click();
		
		dates.get(4).click();
		
		
					
		
	}
	
	
	
	/*** Reporting **/
	
	public void reportPass(String passMsg){
		
		test.log(LogStatus.PASS, passMsg);
	}
	
	public void reportFail(String failureMsg){
		
		getSreenshot();
		test.log(LogStatus.FAIL, failureMsg);
		Assert.fail(failureMsg);
	}



	protected void getSreenshot() {
		// TODO Auto-generated method stub
		
		Date d = new Date();
		String screenShotFile = d.toString().replace(":", "_").replace(" ", "_")+".png";
		File srcFile =  ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		try
		{
			FileUtils.copyFile(srcFile, new File("C:\\Reports\\"+screenShotFile));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		test.log(LogStatus.INFO, "Screenshoot added below: ("+screenShotFile+")"+test.addScreenCapture("C:\\Reports\\"+screenShotFile));
		
	}
	
}
