package com.cleartrip.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.cleartrip.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;

public class PassngersInfoPage extends BasePage {

	@FindBy(id="AdultTitle1")
	public WebElement adult1;
	
	//@FindBy(id="AdultTitle2")
	//public WebElement adult2;
	
	@FindBy(id="AdultTitle3")
	public WebElement adult3;
	
	@FindBy(id="AdultTitle4")
	public WebElement adult4;
	
	@FindBy(id="mobileNumber")
	public WebElement phoneNumber;
	
	@FindBy(id="travellerBtn")
	public WebElement travelBtn;
	
	public PassngersInfoPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}

	
	public PaymentPage enterPassangerDetails() throws InterruptedException{
		WebElement adult1 = driver.findElement(By.id("AdultTitle1"));

		Select sel1 = new Select(adult1);
		sel1.selectByValue("Mr");
		driver.findElement(By.id("AdultFname1")).sendKeys("John");
		driver.findElement(By.id("AdultLname1")).sendKeys("Peter");
		Thread.sleep(2000);
		WebElement adult2 = driver.findElement(By.id("AdultTitle2"));
		                                              

		Select sel2 = new Select(adult2);
		sel2.selectByValue("Mr");
		driver.findElement(By.id("AdultFname2")).sendKeys("John");
		driver.findElement(By.id("AdultLname2")).sendKeys("Paul");
		
		/*Select sel3 = new Select(adult1);
		sel1.selectByValue("Mr");
		driver.findElement(By.id("AdultFname3")).sendKeys("John");
		driver.findElement(By.id("AdultLname3")).sendKeys("John");
		
		Select sel4 = new Select(adult1);
		sel1.selectByValue("Mr");
		driver.findElement(By.id("AdultFname3")).sendKeys("John");
		driver.findElement(By.id("AdultLname3")).sendKeys("John");*/
		WebElement phoneNumber = driver.findElement(By.id("mobileNumber"));
		phoneNumber.sendKeys("9566212889");
		driver.findElement(By.id("travellerBtn")).click();
		//travelBtn.click();
		
		PaymentPage pmtPage = new PaymentPage(driver, test);
		PageFactory.initElements(driver, pmtPage);
		return pmtPage;
		
		
	}

}
