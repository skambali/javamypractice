package com.cleartrip.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cleartrip.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;

public class EmailAddressPage extends BasePage {

	@FindBy(id="username")
	public WebElement email;
	
	@FindBy(id="LoginContinueBtn_1")
	public WebElement contnue;
	
	
	
	public EmailAddressPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}
	
	public PassngersInfoPage enterEmail(){
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.id("username")).sendKeys("krevanna@gmail.com");
		driver.findElement(By.id("LoginContinueBtn_1")).click();
		//email.sendKeys("anil.bvn@gmail.com");
		//contnue.click();
		
		PassngersInfoPage passangersInfo = new PassngersInfoPage(driver, test);
		PageFactory.initElements(driver, passangersInfo);
		return passangersInfo;
		
		
		
	}

}
