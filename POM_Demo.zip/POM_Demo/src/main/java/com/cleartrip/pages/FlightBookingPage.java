package com.cleartrip.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cleartrip.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;

public class FlightBookingPage extends BasePage {

	@FindBy(id="insurance_confirm")
	public WebElement insurance;
	
	@FindBy(id="itineraryBtn")
	public WebElement contBooking;
	
	public FlightBookingPage(WebDriver driver, ExtentTest test) {
		// TODO Auto-generated constructor stub
		super(driver, test);
	}
	
	
	public EmailAddressPage continueBooking(){
		
		//insurance.click();
		driver.findElement(By.id("insurance_confirm")).click();
		driver.findElement(By.id("itineraryBtn")).click();
		//contBooking.click();
		
		EmailAddressPage emailAddrPage = new EmailAddressPage(driver, test);
		PageFactory.initElements(driver, emailAddrPage);
		return emailAddrPage;
		
	}

}


