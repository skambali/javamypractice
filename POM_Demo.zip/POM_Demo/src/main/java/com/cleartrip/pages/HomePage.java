package com.cleartrip.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cleartrip.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class HomePage extends BasePage {

	
		
	public HomePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}
	
	
	public FlightsListPage searchFlights() throws InterruptedException{
		
		test.log(LogStatus.INFO, "Searching Flights");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.id("RoundTrip")).click();
		//Thread.sleep(millis);
		//roundTrip.click();
		
		driver.findElement(By.id("FromTag")).sendKeys("Hyd");
		//driver.findElement(By.id("FromTag")).sendKeys(Keys.DOWN);
		driver.findElement(By.id("FromTag")).sendKeys(Keys.ENTER);
		test.log(LogStatus.INFO, "Selected source location");
		Thread.sleep(2000);
		driver.findElement(By.id("ToTag")).sendKeys("MAA");
		//driver.findElement(By.id("ToTag")).sendKeys(Keys.DOWN);
		driver.findElement(By.id("ToTag")).sendKeys(Keys.ENTER);
		test.log(LogStatus.INFO, "Selected destination location");
		//from.sendKeys("Hyd");
		
		//to.sendKeys("MAA");
		
		List<WebElement> dates = driver.findElements(By.xpath("//i[contains(@class, 'datePicker')]"));
		dates.get(0).click();
		
		System.out.println("Calendar Size: "+dates.size());
		//System.out.println("Clik on Next");
		//driver.findElement(By.xpath("//a[@title='Next']")).click();
		Thread.sleep(5000);
		System.out.println("Clicked on Next");

		//date.click();
		WebElement clndr = driver.findElement(By.className("calendar"));
		WebElement tbody = clndr.findElement(By.tagName("tbody"));
		List<WebElement> datesValue = tbody.findElements(By.tagName("tr"));
		
		System.out.println("Total rows are: "+datesValue.size());
		
		
		List<WebElement> datVals = datesValue.get(4).findElements(By.tagName("td"));
		
		List<WebElement> tdVals = driver.findElements(By.tagName("td"));
		
		System.out.println("TD Values: "+tdVals.size());
		
		System.out.println("Date Values: "+datVals.size());
		Thread.sleep(2000);
		//System.out.println(driver.getPageSource());
		WebElement startDate = datVals.get(2);
		System.out.println("Start Date is: "+startDate.getText());
		//WebDriverWait wait = new WebDriverWait(driver, 30);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", startDate);
		//startDate.click();
		System.out.println("Clicked");
		//datVals.get(0).click();
		Thread.sleep(5000);
		System.out.println("========================================");
		System.out.println("Total rows are 1: "+datesValue.size());
		System.out.println("TD Values 1: "+tdVals.size());
		System.out.println("Date Values 1: "+datVals.size());
		System.out.println("========================================");
		
		//dates.get(1).click();
		
		WebElement clndr1 = driver.findElement(By.className("calendar"));
		WebElement tbody1 = clndr1.findElement(By.tagName("tbody"));
		List<WebElement> datesValue1 = tbody1.findElements(By.tagName("tr"));
		
		System.out.println("Total rows are ..... : "+datesValue1.size());
		
		
		List<WebElement> datVals1 = datesValue1.get(4).findElements(By.tagName("td"));
		
		List<WebElement> tdVals1 = driver.findElements(By.tagName("td"));
		
		WebElement endDate = datVals1.get(5);
		
		//WebElement endDate = datVals.get(2);
		
		System.out.println("End Date is: "+endDate.getText());
		Thread.sleep(2000);
		//JavascriptExecutor js1 = (JavascriptExecutor) driver;

		js.executeScript("arguments[0].click();", endDate);
		//datVals.get(5).click();
		
		//selFromToDate();
		//adults.click();
		
		WebElement adults = driver.findElement(By.id("Adults"));
		Select sel = new Select(adults);
		sel.selectByIndex(1);
		
		driver.findElement(By.id("SearchBtn")).click();
		//searchFlights.click();
		
		FlightsListPage flightsPage = new FlightsListPage(driver, test);
		PageFactory.initElements(driver, flightsPage);
		
		return flightsPage;
	}
	

}
