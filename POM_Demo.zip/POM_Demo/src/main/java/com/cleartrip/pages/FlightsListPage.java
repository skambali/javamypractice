package com.cleartrip.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cleartrip.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class FlightsListPage extends BasePage{

	
	public FlightsListPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
	}
	
	public FlightBookingPage bookFlight(){
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//WebDriverWait wait = new WebDriverWait(driver, 30);
		//wait.until(ExpectedConditions.visibilityOf((WebElement) By.className("totalAmount")));
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Book']")));
		
		List<WebElement> rndTripHear = driver.findElements(By.xpath("//div[contains(@class, 'actionCol')]"));
		
		System.out.println("Book buttons "+rndTripHear.size());
		
		WebElement book = rndTripHear.get(1);
		System.out.println(book.getAttribute("class"));
		book.click();
		
		test.log(LogStatus.INFO, "Flights returned for search criteria");
		//WebElement sbmt = rndTripHear.findElement(By.xpath("//button[@type='submit']"));
		
		//WebElement ttlAmt = driver.findElement(By.id("totalAmount"));
		//System.out.println("Total Amount: "+sbmt.getText());
		
		//driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		FlightBookingPage bookFlight = new FlightBookingPage(driver, test);
		
		PageFactory.initElements(driver, bookFlight);
		return bookFlight;
		//return new bookFlight;
		
	}

}
