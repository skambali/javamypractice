package com.cleartrip.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cleartrip.base.BasePage;
import com.relevantcodes.extentreports.ExtentTest;

public class PaymentPage extends BasePage {

	public PaymentPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}
	
	public void makePayment() throws InterruptedException{
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("paymentSubmit")));
		
		Thread.sleep(5000);
		getSreenshot();
		
		Thread.sleep(5000);
	}

}
