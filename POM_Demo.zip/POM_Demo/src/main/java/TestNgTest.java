import org.testng.annotations.Test;

public class TestNgTest {
	
	@Test
	public void test1(){
		
		System.out.println("Test 1");
		
	}

}


