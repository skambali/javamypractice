package com.cleartrip.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.cleartrip.util.ExtentManager;
import com.cleartrip.util.Xls_Reader;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BaseTest {
	
	public ExtentReports rep = ExtentManager.getInstance();
	public ExtentTest test;
	public WebDriver driver;
	//public Xls_Reader xls = new Xls_Reader("File Path");
	
	@BeforeTest
	public void launchClearTrip(){
		
		driver = new FirefoxDriver();
		driver.manage().deleteAllCookies();
		//test.log(LogStatus.INFO, "Launching App");
		driver.get("https://www.cleartrip.com/");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
	}

	
	@AfterTest
	public void quit(){
		if(rep!=null){
			rep.endTest(test);
			rep.flush();
		}
		
		if(driver!=null){
			driver.quit();
		}
	}
}
