package com.cleartrip.tests;

import org.testng.annotations.Test;

import com.cleartrip.base.BaseTest;
import com.cleartrip.pages.EmailAddressPage;
import com.cleartrip.pages.FlightBookingPage;
import com.cleartrip.pages.FlightsListPage;
import com.cleartrip.pages.HomePage;
import com.cleartrip.pages.PassngersInfoPage;
import com.cleartrip.pages.PaymentPage;

public class SearchFlight extends BaseTest{
	
	@Test
	public void searchFlight() throws InterruptedException{
		
		String testName="FlightRoundTrip";
		test=rep.startTest(testName);
		
		
		HomePage homePage = new HomePage(driver, test);
		homePage.searchFlights();
		FlightsListPage listPage = new FlightsListPage(driver, test);
		listPage.bookFlight();
		FlightBookingPage bookPage = new FlightBookingPage(driver, test);
		bookPage.continueBooking();
		EmailAddressPage emailId = new EmailAddressPage(driver, test);
		emailId.enterEmail();
		PassngersInfoPage psngrInfo = new PassngersInfoPage(driver, test);
		psngrInfo.enterPassangerDetails();
		PaymentPage pmtPage = new PaymentPage(driver, test);
		pmtPage.makePayment();
		//FlightBookingPage booking = new FlightBookingPage(driver, test);
		//booking.b
	}

}
